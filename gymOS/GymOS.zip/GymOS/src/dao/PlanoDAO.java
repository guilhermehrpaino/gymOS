/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import conexao.Conexao;
import dto.PlanoDTO;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author Guilherme
 */
public class PlanoDAO {
    Connection conn;
    PreparedStatement pstm;
    
    ResultSet rs;
    
    
    public void criarPlano(PlanoDTO planoDTO) {
        String sql = "INSERT INTO plano(nome_plano, valor_plano, duracao_meses) "
                + "VALUES(?, ?, ?)";
        
        conn = Conexao.getConexao();
        try {
            pstm = conn.prepareStatement(sql);
            pstm.setString(1, planoDTO.getNomePlano());
            pstm.setDouble(2, planoDTO.getValorPlano());
            pstm.setInt(3, planoDTO.getDuracaoMeses());
            pstm.execute();
            pstm.close();
        } catch(SQLException e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }
    
    
    public List<PlanoDTO> listarPlanos() {
       
       List<PlanoDTO> lista = new ArrayList<>();
       String sql = "SELECT * FROM plano";
        try (Connection conn = Conexao.getConexao();
            PreparedStatement pstm = conn.prepareStatement(sql);
            ResultSet rs = pstm.executeQuery()) {
                 while (rs.next()) {
                     PlanoDTO plano = new PlanoDTO();
                     plano.setId_plano(rs.getInt("id_plano"));
                     plano.setNomePlano(rs.getString("nome_plano"));
                     Double valorPlano = rs.getDouble("valor_plano");
                     plano.setValorPlano(valorPlano);
                     plano.setDuracaoMeses(rs.getInt("duracao_meses"));
                     lista.add(plano);
                     }
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao listar Planos", e);
        }

    return lista;
    }

    public PlanoDTO buscarPorId(int idPlano) {
        String sql = "SELECT * FROM plano WHERE id_plano = ?";
        PlanoDTO plano = new PlanoDTO();
            try(Connection conn = Conexao.getConexao();
                PreparedStatement pstm = conn.prepareStatement(sql);) {
                    pstm.setInt(1, idPlano);
                    
                    try (ResultSet rs = pstm.executeQuery()) {
                        if(rs.next()) {
                            plano.setId_plano(rs.getInt("id_plano"));
                            plano.setNomePlano(rs.getString("nome_plano"));
                            Double valorPlano = rs.getDouble("valor_plano");
                            plano.setValorPlano(valorPlano);
                            plano.setDuracaoMeses(rs.getInt("duracao_meses"));
                        }
                    }
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, e);
            }
            return plano;
    }
    
    public void alterarPlano(PlanoDTO planoDTO) {
        String sql = "UPDATE plano SET nome_plano = ?, valor_plano = ?, duracao_meses = ? WHERE id_plano = ?";
        conn = Conexao.getConexao();
        try {
            pstm = conn.prepareStatement(sql);
            pstm.setString(1, planoDTO.getNomePlano());
            pstm.setDouble(2, planoDTO.getValorPlano());
            pstm.setInt(3, planoDTO.getDuracaoMeses());
            pstm.setInt(4, planoDTO.getId_plano());
            pstm.execute();
            pstm.close();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }
    
    public void excluirPlano(PlanoDTO planoDTO) {
        String sql = "DELETE from plano WHERE id_plano = ?";
        conn = Conexao.getConexao();
        
        try {
            pstm = conn.prepareStatement(sql);
            pstm.setInt(1, planoDTO.getId_plano());
            pstm.execute();
            pstm.close();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }
    
}
