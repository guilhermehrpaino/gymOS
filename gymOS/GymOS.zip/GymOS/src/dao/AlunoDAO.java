/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import conexao.Conexao;
import dto.AlunoDTO;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author Guilherme
 */
public class AlunoDAO {
    Connection conn;
    PreparedStatement pstm;
    
    ResultSet rs;
    ArrayList<AlunoDTO> lista = new ArrayList<>();

    public void cadastrarAluno(AlunoDTO alunoDTO ) {
        String sql = "insert into aluno(nome, cpf, telefone, email, data_nascimento) "
                +     "values (?,?,?,?, ?)";
        
//conn = (Connection) new Conexao();
// connection = Conexao.getConexao();
        conn = Conexao.getConexao();
        try {
            pstm = conn.prepareStatement(sql);
            pstm.setString(1, alunoDTO.getNome());
            pstm.setString(2, alunoDTO.getCpf());
            pstm.setString(3, alunoDTO.getTelefone());
            pstm.setString(4, alunoDTO.getEmail());
            pstm.setObject(5, alunoDTO.getDataNasc());
            pstm.execute();
            pstm.close();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }

    
    public ArrayList<AlunoDTO> listarAlunos() {
        String sql = "select * from aluno";
        ArrayList<AlunoDTO> lista = new ArrayList<>();

        try (Connection conn = Conexao.getConexao();
            PreparedStatement pstm = conn.prepareStatement(sql);

            ResultSet rs = pstm.executeQuery()) {
                while (rs.next()) {
                    AlunoDTO aluno = new AlunoDTO();
                    aluno.setId_aluno(rs.getInt("id_aluno"));
                    aluno.setNome(rs.getString("nome"));
                    aluno.setCpf(rs.getString("cpf"));
                    aluno.setTelefone(rs.getString("telefone"));
                    aluno.setEmail(rs.getString("email"));
                    LocalDate dataNasc = rs.getObject("data_nascimento", LocalDate.class);
                    aluno.setDataNasc(dataNasc);
                    lista.add(aluno);
                    }
                } catch (SQLException e) {
                    throw new RuntimeException("Erro ao listar clientes", e);
            }

        return lista;
    }
    
    public ArrayList<AlunoDTO> listarAlunosSemMatricula() {
        String sql = "SELECT a.* FROM aluno a WHERE NOT EXISTS (SELECT 1 FROM matricula m WHERE m.id_aluno = a.id_aluno AND m.status = 'ATIVO'); ";
        ArrayList<AlunoDTO> lista = new ArrayList<>();

        try (Connection conn = Conexao.getConexao();
            PreparedStatement pstm = conn.prepareStatement(sql);

            ResultSet rs = pstm.executeQuery()) {
                while (rs.next()) {
                    AlunoDTO aluno = new AlunoDTO();
                    aluno.setId_aluno(rs.getInt("id_aluno"));
                    aluno.setNome(rs.getString("nome"));
                    aluno.setCpf(rs.getString("cpf"));
                    aluno.setTelefone(rs.getString("telefone"));
                    aluno.setEmail(rs.getString("email"));
                    LocalDate dataNasc = rs.getObject("data_nascimento", LocalDate.class);
                    aluno.setDataNasc(dataNasc);
                    lista.add(aluno);
                    }
                } catch (SQLException e) {
                    throw new RuntimeException("Erro ao listar clientes", e);
            }

        return lista;
    }
    
    
    public void alterarAluno(AlunoDTO alunoDTO) {
        String sql = "update aluno set nome = ?, cpf = ?, telefone = ?, email = ?, data_nascimento = ? where id_aluno = ?";
        conn = Conexao.getConexao();
        try {
            pstm = conn.prepareStatement(sql);
            pstm.setString(1, alunoDTO.getNome());
            pstm.setString(2, alunoDTO.getCpf());
            pstm.setString(3, alunoDTO.getTelefone());
            pstm.setString(4, alunoDTO.getEmail());
            pstm.setObject(5, alunoDTO.getDataNasc());
            pstm.setInt(6, alunoDTO.getId_aluno());
            pstm.execute();
            pstm.close();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }
  
    public void excluirAluno(AlunoDTO alunoDTO) {
        String sql = "DELETE FROM aluno WHERE id_aluno = ?";
        conn = Conexao.getConexao();
        try {
            pstm = conn.prepareStatement(sql);
            pstm.setInt(1, alunoDTO.getId_aluno());
            pstm.execute();
            pstm.close();
        } catch(SQLException e ) {
            JOptionPane.showMessageDialog(null, e);
        }
    }
    
    public int contagemTotalAlunos() {
        String sql = "SELECT COUNT(DISTINCT id_aluno) FROM aluno";
        conn = Conexao.getConexao();
        
        try {
            pstm = conn.prepareStatement(sql);
            ResultSet rs = pstm.executeQuery();
            
            if(rs.next()) {
                return rs.getInt(1);
            }
        } catch(SQLException e) {
           JOptionPane.showMessageDialog(null, e);
        }
        return 0;
    }
    
    
}
