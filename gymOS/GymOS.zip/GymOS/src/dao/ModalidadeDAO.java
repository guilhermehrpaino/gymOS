/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import conexao.Conexao;
import dto.ModalidadeDTO;
import dto.ModalidadeDTO;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author Guilherme
 */
public class ModalidadeDAO {
    Connection conn;
    PreparedStatement pstm;
    
    ResultSet rs;
    
    public static ModalidadeDTO buscarPorId(int idModalidade) {
        String sql = "SELECT * FROM modalidade WHERE id_modalidade = ?";
        ModalidadeDTO plano = new ModalidadeDTO();
            try(Connection conn = Conexao.getConexao();
                PreparedStatement pstm = conn.prepareStatement(sql);) {
                    pstm.setInt(1, idModalidade);
                    
                    try (ResultSet rs = pstm.executeQuery()) {
                        if(rs.next()) {
                            plano.setId_modalidade(rs.getInt("id_modalidade"));
                            plano.setNomeModalidade(rs.getString("nome_modalidade"));
                            plano.setDescricao(rs.getString("descricao"));
                        }
                    }
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, e);
            }
            return plano;
    }

    public void criarModalidade(ModalidadeDTO modalidade) {
        String sql = "INSERT INTO modalidade(nome_modalidade, descricao) "
                + "VALUES(?, ?)";
        
        conn = Conexao.getConexao();
        try {
            pstm = conn.prepareStatement(sql);
            pstm.setString(1, modalidade.getNomeModalidade());
            pstm.setString(2, modalidade.getDescricao());
            pstm.execute();
            pstm.close();
        } catch(SQLException e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }

    public void alterarModalidade(ModalidadeDTO modalidade) {
        String sql = "UPDATE modalidade SET nome_modalidade = ?, descricao = ? WHERE id_modalidade = ?";
        conn = Conexao.getConexao();
        try {
            pstm = conn.prepareStatement(sql);
            pstm.setString(1, modalidade.getNomeModalidade());
            pstm.setString(2, modalidade.getDescricao());
            pstm.setInt(3, modalidade.getId_modalidade());
            pstm.execute();
            pstm.close();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }

    public void excluirModalidade(ModalidadeDTO modalidade) {
       String sql = "DELETE from modalidade WHERE id_modalidade = ?";
        conn = Conexao.getConexao();
        try {
            pstm = conn.prepareStatement(sql);
            pstm.setInt(1, modalidade.getId_modalidade());
            pstm.execute();
            pstm.close();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }

    public List<ModalidadeDTO> listarModalidades() {
       List<ModalidadeDTO> lista = new ArrayList<>();
       String sql = "SELECT * FROM modalidade";
        try (Connection conn = Conexao.getConexao();
            PreparedStatement pstm = conn.prepareStatement(sql);
            ResultSet rs = pstm.executeQuery()) {
                 while (rs.next()) {
                     ModalidadeDTO modalidade = new ModalidadeDTO();
                     modalidade.setId_modalidade(rs.getInt("id_modalidade"));
                     modalidade.setNomeModalidade(rs.getString("nome_modalidade"));
                     modalidade.setDescricao(rs.getString("descricao"));
                     lista.add(modalidade);
                     }
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao listar Modalidades", e);
        }

    return lista;
    }
    
    
    public String listarModalidadeMaisPopular() {
        String sql = "SELECT m.nome_modalidade, COUNT(*) AS quantidade FROM matricula ma "
                + " INNER JOIN modalidade m ON ma.id_modalidade = m.id_modalidade GROUP BY"
                + " m.id_modalidade, m.nome_modalidade ORDER BY quantidade DESC LIMIT 1";
        
        conn = Conexao.getConexao();
        try {
            pstm = conn.prepareStatement(sql);
            rs = pstm.executeQuery();
            
            if (rs.next()){
                return rs.getString("nome_modalidade");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e);
        }
        return "Sem dados";
    }
}
