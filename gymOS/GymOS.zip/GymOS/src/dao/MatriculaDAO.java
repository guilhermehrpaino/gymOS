/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import conexao.Conexao;
import dto.AlunoDTO;
import dto.MatriculaDTO;
import dto.ModalidadeDTO;
import dto.PlanoDTO;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author Guilherme
 */
public class MatriculaDAO {
    Connection conn;
    PreparedStatement pstm;
    ResultSet rs;
    
    
    public ArrayList<MatriculaDTO> listaGeral() {
        ArrayList<MatriculaDTO> lista = new ArrayList<>();
        
       String sql = "SELECT m.id_matricula, a.id_aluno, p.id_plano, a.nome, p.nome_plano, m.status, a.data_nascimento, m.data_inicio, m.data_fim " +
             "FROM matricula m " +
             "INNER JOIN aluno a ON m.id_aluno = a.id_aluno " +
             "INNER JOIN plano p ON m.id_plano = p.id_plano ORDER BY id_matricula";
       conn = Conexao.getConexao();
       
       try {
           pstm = conn.prepareStatement(sql);
           rs = pstm.executeQuery();
           while (rs.next()) {
               
               
               MatriculaDTO obj = new MatriculaDTO();
               AlunoDTO aluno = new AlunoDTO();
               PlanoDTO plano = new PlanoDTO();
               
               aluno.setId_aluno(rs.getInt("id_matricula"));
               aluno.setNome(rs.getString("nome"));
               LocalDate dataNasc = rs.getObject("data_nascimento", LocalDate.class);
               aluno.setDataNasc(dataNasc);
               
               plano.setId_plano(rs.getInt("id_plano"));
               plano.setNomePlano(rs.getString("nome_plano"));
              
               
               obj.setId_aluno(aluno);
               obj.setId_plano(plano);
               obj.setStatus(rs.getString("status"));
               LocalDate dataInicio = rs.getObject("data_inicio", LocalDate.class);
               LocalDate dataFim = rs.getObject("data_fim", LocalDate.class);
               obj.setDataInicio(dataInicio);
               obj.setDataFim(dataFim);
               
               lista.add(obj);
               
           }
       } catch(Exception e) {
            e.printStackTrace();
         }
       
       return lista;
    }
    
    public void criarMatricula(int id_aluno, int id_plano, int id_modalidade) {
        PlanoDAO dao = new PlanoDAO();
        PlanoDTO plano = new PlanoDTO();
        plano = dao.buscarPorId(id_plano);
        LocalDate dataFim = LocalDate.now().plusMonths(plano.getDuracaoMeses());
        
        
        String sql = "insert into matricula(id_aluno, id_plano, id_modalidade, data_inicio, data_fim, status) "
                +     "values (?,?,?,?,?,?)";
        
//conn = (Connection) new Conexao();
// connection = Conexao.getConexao();
        conn = Conexao.getConexao();
        try {
            pstm = conn.prepareStatement(sql);
            pstm.setInt(1, id_aluno);
            pstm.setInt(2, id_plano);
            pstm.setInt(3, id_modalidade);
            pstm.setObject(4, LocalDate.now());
            pstm.setObject(5, dataFim);
            pstm.setString(6, "ATIVO");
            pstm.execute();
            pstm.close();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }

    public void atualizarMatricula(int idMatricula, int idModalidade, String status) {
        String sql = "UPDATE matricula SET id_modalidade = ?, status = ? WHERE id_matricula = ?";
        
        conn = Conexao.getConexao();
        try {
            pstm = conn.prepareStatement(sql);
            
            pstm.setInt(1, idModalidade);
            pstm.setString(2, status);
            pstm.setInt(3, idMatricula);
            
            pstm.executeUpdate();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }
    
    
    public void verificarStatus() {
       String sql = "UPDATE matricula SET status = 'INATIVO' WHERE status = 'ATIVO' AND data_fim < CURRENT_DATE";
       conn = Conexao.getConexao();
       try {
            pstm = conn.prepareStatement(sql); 
            pstm.execute();
       } catch(SQLException e) {
           JOptionPane.showMessageDialog(null, e);
       }
       
    }
    
    public int listarMatriculasAtivas() {
        String sql = "SELECT COUNT(DISTINCT id_matricula) FROM matricula WHERE status = 'ATIVO' ";
        conn = Conexao.getConexao();
        try {
            pstm = conn.prepareStatement(sql);
            rs = pstm.executeQuery();
            
            if (rs.next()) {
                return rs.getInt(1);
            }
            
        } catch (SQLException e ) {
            JOptionPane.showMessageDialog(null, e);
        } 
        return 0;
    }
    
    public MatriculaDTO buscarMatriculaPorId(int id) {
        MatriculaDTO matriculaDTO = null;
         String sql = "SELECT "
            + "m.id_matricula, m.status, "
            + "a.id_aluno, a.nome, a.cpf, a.telefone, "
            + "a.email, a.data_nascimento, "
            + "p.id_plano, p.nome_plano, "
            + "md.id_modalidade,md.nome_modalidade "
            + "FROM matricula m "
            + "INNER JOIN aluno a ON m.id_aluno = a.id_aluno "
            + "INNER JOIN plano p ON m.id_plano = p.id_plano "
            + "INNER JOIN modalidade md ON m.id_modalidade = md.id_modalidade "
            + "WHERE m.id_matricula = ?";

        conn = Conexao.getConexao();
        try {
            pstm = conn.prepareStatement(sql);
            pstm.setInt(1, id);
            
            rs = pstm.executeQuery();
            
            if (rs.next()){
                matriculaDTO = new MatriculaDTO();
                AlunoDTO aluno = new AlunoDTO();
                PlanoDTO plano = new PlanoDTO();
                ModalidadeDTO modalidade = new ModalidadeDTO();
                
              
                aluno.setId_aluno(rs.getInt("id_aluno"));
                aluno.setNome(rs.getString("nome"));
                aluno.setCpf(rs.getString("cpf"));
                aluno.setTelefone(rs.getString("telefone"));
                aluno.setEmail(rs.getString("email"));
                aluno.setDataNasc(
                    rs.getObject("data_nascimento", LocalDate.class)
                );


                plano.setId_plano(rs.getInt("id_plano"));
                plano.setNomePlano(rs.getString("nome_plano"));


                modalidade.setId_modalidade(rs.getInt("id_modalidade"));
                modalidade.setNomeModalidade(
                    rs.getString("nome_modalidade")
                );


                matriculaDTO.setId_matricula(
                    rs.getInt("id_matricula")
                );
                matriculaDTO.setStatus(rs.getString("status"));

                matriculaDTO.setId_aluno(aluno);
                matriculaDTO.setId_plano(plano);
                matriculaDTO.setId_modalidade(modalidade);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e);
        }
        
        return matriculaDTO;
    }
}
