/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dto;

import java.time.LocalDate;

/**
 *
 * @author Guilherme
 */
public class MatriculaDTO {
    
    private int id_matricula;
    
    private AlunoDTO id_aluno;
    
    private PlanoDTO id_plano;
    
    private ModalidadeDTO id_modalidade;
    
    private LocalDate dataInicio;
    
    private LocalDate dataFim;
    
    private String status;

    public MatriculaDTO() {
    }

    public ModalidadeDTO getId_modalidade() {
        return id_modalidade;
    }

    public void setId_modalidade(ModalidadeDTO id_modalidade) {
        this.id_modalidade = id_modalidade;
    }

    
    
    
    public int getId_matricula() {
        return id_matricula;
    }

    public void setId_matricula(int id_matricula) {
        this.id_matricula = id_matricula;
    }

    public AlunoDTO getId_aluno() {
        return id_aluno;
    }

    public void setId_aluno(AlunoDTO id_aluno) {
        this.id_aluno = id_aluno;
    }

    public PlanoDTO getId_plano() {
        return id_plano;
    }

    public void setId_plano(PlanoDTO id_plano) {
        this.id_plano = id_plano;
    }

    public LocalDate getDataInicio() {
        return dataInicio;
    }

    public void setDataInicio(LocalDate dataInicio) {
        this.dataInicio = dataInicio;
    }

    public LocalDate getDataFim() {
        return dataFim;
    }

    public void setDataFim(LocalDate dataFim) {
        this.dataFim = dataFim;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
    
    
    
   
}
