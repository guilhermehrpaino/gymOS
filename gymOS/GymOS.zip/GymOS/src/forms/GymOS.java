/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package forms;

/**
 *
 * @author Guilherme
 */
public class GymOS {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        frmPrincipal runMain = new frmPrincipal();
        runMain.setVisible(true);
    }
    
}
